<?php 
/*
 * This is the page users will see logged out. 
 * You can edit this, but for upgrade safety you should copy and modify this file into your template folder.
 * The location from within your template folder is plugins/login-with-ajax/ (create these directories if they don't exist)
*/
?>
<?php
	if( $is_widget ){
		echo $before_widget . $before_title . '<span id="LoginWithAjax_Title">' . __('Log In') . '</span>' . $after_title;
	}
?>
	<a href="/" id="LoginWithAjax_Links_Login" rel="#LoginWithAjax_Modal"><?php _e('Log In') ?></a>
<?php
	if( $is_widget ){
		echo $after_widget;
	}
?>