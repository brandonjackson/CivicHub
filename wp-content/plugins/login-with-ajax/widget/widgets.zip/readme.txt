We are working on a widget template choice feature, but due to loading of CSS and JS decisions being made on the fly we're still taking the time to find the best solution so it's as future-proof as possible.

That said, the files in this file are example variations of templates for the LWA widget.

Feel free to give us your suggestions on our forum!